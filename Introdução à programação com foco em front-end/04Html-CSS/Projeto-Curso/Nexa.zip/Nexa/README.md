Link do Figma
https://www.figma.com/file/eAIA7DAU60ZOyWclw7ifZ2/projeto?type=design&node-id=0%3A1&mode=design&t=d0Jx1S9wHFb0BQ6A-1
